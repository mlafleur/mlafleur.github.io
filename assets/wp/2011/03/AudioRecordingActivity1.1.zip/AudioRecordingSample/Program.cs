using System;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Workflow.Runtime;
using Microsoft.Rtc.Collaboration;
using Microsoft.Rtc.Collaboration.AudioVideo;
using Microsoft.Rtc.Signaling;
using Microsoft.Rtc.Workflow.Activities;

namespace AudioRecordingSample
{
    static class Program
    {
        private static CollaborationPlatform _collabPlatform;
        private static ApplicationEndpoint _endpoint;
        private static WorkflowRuntime _workflowRuntime;
        private static ReaderWriterLock _shutdownLock = new ReaderWriterLock();
        private static bool _shuttingDown;

        private static void Main()
        {
            Initialize();

            Console.WriteLine("Press Enter to stop.");
            Console.ReadLine();

            Cleanup();
        }

        private static void Initialize()
        {
            Console.Write("Initializing the Workflow Runtime... ");
            InitializeWorkflow();
            Console.WriteLine("Complete");
            
            // Platform configuration
            // NOTE: You can change the port here (5065) to any port you like
            ServerPlatformSettings platformSettings = new ServerPlatformSettings("AppPlatform", Dns.GetHostEntry("localhost").HostName, 5065 , null);
            _collabPlatform = new CollaborationPlatform(platformSettings);
            

            Console.Write("Starting Platform... ");
            _collabPlatform.EndStartup(_collabPlatform.BeginStartup(null, null));
            Console.WriteLine("Complete");

            ApplicationEndpointSettings settings = new ApplicationEndpointSettings("sip:server@" + Dns.GetHostEntry("localhost").HostName);
            _endpoint = new ApplicationEndpoint(_collabPlatform, settings);
            _endpoint.RegisterForIncomingCall<AudioVideoCall>(AudioVideoCallReceived);
            _endpoint.RegisterForIncomingCall<InstantMessagingCall>(InstantMessagingCallReceived);

            Console.Write("Establishing Endpoint... ");
            _endpoint.EndEstablish(_endpoint.BeginEstablish(null, _endpoint));
            Console.WriteLine("Complete");

            Console.WriteLine("");
            Console.WriteLine("Host Address - " + settings.OwnerUri.ToLower() + ":" + platformSettings.ListeningPort);
        }

        private static void InitializeWorkflow()
        {
            _workflowRuntime = new WorkflowRuntime();
            _workflowRuntime.AddService(new CommunicationsWorkflowRuntimeService());
            _workflowRuntime.AddService(new TrackingDataWorkflowRuntimeService());

            _workflowRuntime.StartRuntime();
        }

        private static void Cleanup()
        {
            _shuttingDown = true;
            // The purpose of acquiring the writer lock is to ensure that AudioVideoCallReceived and InstantMessagingCallReceived
            // have incremented if they are going to.  We don't actually need to put anything inside the lock.
            _shutdownLock.AcquireWriterLock(Timeout.Infinite);
            _shutdownLock.ReleaseWriterLock();

            if (_workflowRuntime != null)
            {
                ManualResetEvent workflowRuntimeStopped = new ManualResetEvent(false);
                _workflowRuntime.Stopped += delegate(object sender, WorkflowRuntimeEventArgs e)
                {
                    workflowRuntimeStopped.Set();
                };

                _workflowRuntime.StopRuntime();

                int timeoutSecs = 45;
                bool signaled = workflowRuntimeStopped.WaitOne(TimeSpan.FromSeconds(timeoutSecs), false);
                Debug.Assert(signaled, "Workflow runtime still in progress after " + timeoutSecs + " secs, shutting down anyway.");

                _workflowRuntime.Dispose();
                _workflowRuntime = null;
            }

            // Terminate the endpoint once the workflow runtime is finished.
            if (_endpoint != null)
            {
                _endpoint.EndTerminate(_endpoint.BeginTerminate(null, null));
                _endpoint = null;
            }
        }

        /// <summary>
        /// EventHandler raised when an incoming invite arrives.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void AudioVideoCallReceived(object sender, CallReceivedEventArgs<AudioVideoCall> e)
        {
            Debug.Assert(e != null, "e != null");
            Debug.Assert(e.RequestData != null, "e.RequestData != null");
            StartWorkflow(e.Call, e.RequestData);
        }

        /// <summary>
        /// EventHandler raised when an incoming instant message arrives.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void InstantMessagingCallReceived(object sender, CallReceivedEventArgs<InstantMessagingCall> e)
        {
            Debug.Assert(e != null, "e != null");
            Debug.Assert(e.RequestData != null, "e.RequestData != null");
            StartWorkflow(e.Call, e.RequestData);
        }

        private static void StartWorkflow(Call call, SipRequestData requestData)
        {
            Debug.Assert(call != null, "call != null");
            Debug.Assert(call is AudioVideoCall || call is InstantMessagingCall,
                "Only AudioVideoCall and InstantMessagingCall are subscribed to above.");

            WorkflowInstance workflowInstance = _workflowRuntime.CreateWorkflow(typeof(Workflow1));
            Debug.Assert(workflowInstance != null, "workflowInstance != null");

            CommunicationsWorkflowRuntimeService communicationsWorkflowRuntimeService = (CommunicationsWorkflowRuntimeService)
                _workflowRuntime.GetService(typeof(CommunicationsWorkflowRuntimeService));
            Debug.Assert(communicationsWorkflowRuntimeService != null, "communicationsWorkflowRuntimeService != null");

            try
            {
                communicationsWorkflowRuntimeService.EnqueueCall(workflowInstance.InstanceId, call);
                communicationsWorkflowRuntimeService.SetEndpoint(workflowInstance.InstanceId, _endpoint);
                communicationsWorkflowRuntimeService.SetWorkflowCulture(workflowInstance.InstanceId, new CultureInfo("en-US"));
            }
            catch (InvalidOperationException ex)
            {
                call.EndTerminate(call.BeginTerminate(null, null));
                Debug.Fail("Unable to configure the CommunicationsWorkflowRuntimeService: " + ex.ToString());
            }

            _shutdownLock.AcquireReaderLock(Timeout.Infinite);

            try
            {
                if (_shuttingDown)
                {
                    call.EndTerminate(call.BeginTerminate(null, null));
                    return;
                }
            }
            finally
            {
                _shutdownLock.ReleaseReaderLock();
            }

            workflowInstance.Start();
        }
    }
}
