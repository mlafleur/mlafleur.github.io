﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections.Generic;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.Rtc.Workflow.Activities;
using Microsoft.Rtc.Workflow.Common;
using Microsoft.Rtc.Collaboration.AudioVideo;
using Microsoft.Rtc.Collaboration;
using System.Threading;

namespace AudioRecordingActivity
{
    public sealed class AudioRecording : System.Workflow.ComponentModel.Activity, IInstanceDependencyContainer
    {
        private CallProvider _callProvider;
        private DateTime _audioDetected;
        private Recorder _recorder;
        private Timer _silenceTimer;

        public AudioRecording()
        {
            _instanceDependencyProperties = new Dictionary<string, object>();
        }

        public AudioRecording(string name)
            : base(name)
        {
            _instanceDependencyProperties = new Dictionary<string, object>();
        }

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            this._callProvider = Utilities.GetCallProviderFromParent<AudioVideoCall>(this);
            Call call = this._callProvider.Call;

            try
            {
                if (this._callProvider.Call.State == CallState.Established)
                {
                    _recorder = new Recorder();
                    _recorder.VoiceActivityChanged += new EventHandler<VoiceActivityChangedEventArgs>(_recorder_VoiceActivityChanged);


                    WmaFileSink fileSink;
                    if (string.IsNullOrEmpty(FileName))
                        FileName = Guid.NewGuid().ToString() + ".wma";


                    fileSink = new WmaFileSink(FileName);

                    fileSink.EncodingFormat = EncodingFormat;

                    _recorder.SetSink(fileSink);

                    AudioVideoCall avCall = (AudioVideoCall)_callProvider.Call;
                    _recorder.AttachFlow(avCall.Flow);

                    _recorder.Start();
                    while (_recorder.State == RecorderState.Started)
                    {
                        // Loop while we wait for things to be done
                    }
                    RecordingLength = (DateTime.Now - _audioDetected);

                }
                return ActivityExecutionStatus.Closed;
            }
            catch
            {
                return ActivityExecutionStatus.Faulting;
            }
        }

        protected override ActivityExecutionStatus Cancel(ActivityExecutionContext executionContext)
        {
            this.Stop();
            return ActivityExecutionStatus.Canceling;
        }

        private void _recorder_VoiceActivityChanged(object sender, VoiceActivityChangedEventArgs e)
        {
            bool audioDetected = e.IsVoice;

            if (audioDetected) // Audio activity was detected
            {
                Console.WriteLine("Audio Activity Detected");
                _audioDetected = DateTime.Now; // Note the time we started getting audio        
                if (_silenceTimer != null)
                {
                    // We've got audio so make sure we don't have a silence timer going
                    _silenceTimer.Dispose();
                    _silenceTimer = null;
                }
            }
            else // We have silence
            {
                if (_audioDetected.Ticks == 0)
                {
                    // This means we've never had audio. Time to start checking to initial silence
                    Console.WriteLine("Starting Initial Silence Detection");
                    _silenceTimer = new Timer(new TimerCallback(OnSilenceTimerFired), null, InitialSilenceTimeout, new TimeSpan(0, 0, 0, 0, -1));
                }
                else
                {
                    // We've had audio so now we're looking for ending silence
                    Console.WriteLine("Starting Ending Silence Detection");
                    _silenceTimer = new Timer(new TimerCallback(OnSilenceTimerFired), null, EndingSilenceTimeout, new TimeSpan(0, 0, 0, 0, -1));
                }
            }
        }

        private void OnSilenceTimerFired(object state)
        {
            if (this._recorder.State != RecorderState.Stopped)
            {
                Console.WriteLine("Silence Timeout Detected");
                this.Stop();
            }
        }

        public void Stop()
        {
            if (_silenceTimer != null)
            {
                // Make sure we don't have a silence timer going
                _silenceTimer.Dispose();
                _silenceTimer = null;
            }

            // Set out recording length
            //_recordingLength = DateTime.Now - _recordingBegan;

            _recorder.Stop();
        }

        #region Initial Silence Timeout
        public readonly static InstanceDependencyProperty InitialSilenceTimeoutProperty = InstanceDependencyProperty.Register(
                                                                        "InitialSilenceTimeout",
                                                                        typeof(TimeSpan),
                                                                        typeof(AudioRecording),
                                                                        new TimeSpan(0, 0, 0, 1, 500));

        [Description("How long should we record silence before we decide the calling isn’t going to start talking")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [TypeConverter(typeof(TimeSpanConverter))]
        public TimeSpan InitialSilenceTimeout
        {
            get { return ((TimeSpan)(InstanceDependencyHelper.GetValue(this, AudioRecording.InitialSilenceTimeoutProperty))); }
            set { InstanceDependencyHelper.SetValue(this, AudioRecording.InitialSilenceTimeoutProperty, value); }
        }
        #endregion

        #region Ending Silence Timeout
        public readonly static InstanceDependencyProperty EndingSilenceTimeoutProperty = InstanceDependencyProperty.Register(
                                                                "EndingSilenceTimeout",
                                                                typeof(TimeSpan),
                                                                typeof(AudioRecording),
                                                                new TimeSpan(0, 0, 0, 0, 850));
        [Description("How long should we record silence before we decided the caller has stopped talking")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [TypeConverter(typeof(TimeSpanConverter))]
        public TimeSpan EndingSilenceTimeout
        {
            get { return ((TimeSpan)(InstanceDependencyHelper.GetValue(this, AudioRecording.EndingSilenceTimeoutProperty))); }
            set { InstanceDependencyHelper.SetValue(this, AudioRecording.EndingSilenceTimeoutProperty, value); }
        }
        #endregion

        #region File Name
        public readonly static InstanceDependencyProperty FileNameProperty = InstanceDependencyProperty.Register(
                                                                "FileName",
                                                                typeof(string),
                                                                typeof(AudioRecording));
        [Description("Full path where we should save the file")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public string FileName
        {
            get { return ((string)(InstanceDependencyHelper.GetValue(this, FileNameProperty))); }
            set { InstanceDependencyHelper.SetValue(this, FileNameProperty, value); }
        }
        #endregion

        #region Encoding Format
        public static InstanceDependencyProperty EncodingFormatProperty = InstanceDependencyProperty.Register(
                                                                "EncodingFormat",
                                                                typeof(WmaEncodingFormat),
                                                                typeof(AudioRecording),
                                                                 WmaEncodingFormat.Pcm16Khz);
        [Description("Encoding Format to use for the file")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public WmaEncodingFormat EncodingFormat
        {
            get { return ((WmaEncodingFormat)(InstanceDependencyHelper.GetValue(this, AudioRecording.EncodingFormatProperty))); }
            set { InstanceDependencyHelper.SetValue(this, AudioRecording.EncodingFormatProperty, value); }
        }
        #endregion

        #region Recording Length
        [NonSerialized]
        private static readonly InstanceDependencyProperty RecordingLengthProperty= InstanceDependencyProperty.Register("RecordingLength", typeof(TimeSpan), typeof(AudioRecording));        

        [TypeConverter(typeof(TimeSpanConverter))]
        public TimeSpan RecordingLength
        {
            get { return (TimeSpan)InstanceDependencyHelper.GetValue<AudioRecording>(this, RecordingLengthProperty); }
            set { InstanceDependencyHelper.SetValue<AudioRecording>(this, RecordingLengthProperty, value); }
        }
        #endregion

        static private Dictionary<string, object> _instanceDependencyProperties;
        public Dictionary<string, object> InstanceDependencyProperties
        {
            get { return _instanceDependencyProperties; }
        }
    }
}
