﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;
using System.Collections;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.Rtc.Workflow.Activities;
using Microsoft.Rtc.Workflow.Common;
using Microsoft.Rtc.Workflow.ActivitiesBase;


namespace AudioRecordingActivity

{
[DesignerSerializer(typeof(CommunicationsWorkflowCodeDomSerializer), typeof(CodeDomSerializer)), , ActivityValidator(typeof(StatementActivityValidator)), CommunicationsWorkflowDescription("StatementDesc"), Designer(typeof(CommunicationsActivityDesigner), typeof(IDesigner)), DesignerSerializer(typeof(CommunicationsWorkflowMarkupSerializer), typeof(WorkflowMarkupSerializer)), ToolboxItem(typeof(ActivityToolboxItem))]
public sealed class SpeechStatementActivity : Activity, IInstanceDependencyContainer
{
    // Fields
    [NonSerialized]
    private bool _callOnHold;
    [NonSerialized]
    private CallProvider _callProvider;
    [NonSerialized]
    private EventHandlerProxy<CallStateChangedEventArgs> _callStatusChangedProxy;
    [NonSerialized]
    private CommunicationsWorkflowRuntimeService _communicationsWorkflowRuntimeService;
    [NonSerialized]
    private EventHandlerProxy<AudioVideoFlowConfigurationChangedEventArgs> _configurationChangedProxy;
    [NonSerialized]
    private Dictionary<string, object> _instanceDependencyProperties;
    [NonSerialized]
    private bool _isAsyncRunning;
    [NonSerialized]
    private string _queueName;
    [NonSerialized]
    private EventHandlerProxy<SpeakCompletedEventArgs> _speakCompletedProxy;
    [NonSerialized]
    private UcmaSpeechDebuggingWorkflowRuntimeService _speechDebuggingWorkflowRuntimeService;
    [NonSerialized]
    private TrackingDataWorkflowRuntimeService _trackingDataWorkflowRuntimeService;
    [NonSerialized]
    private static readonly InstanceDependencyProperty IsDataTrackingEnabledProperty = InstanceDependencyProperty.Register("IsDataTrackingEnabled", typeof(bool), typeof(SpeechStatementActivity), false);
    [NonSerialized]
    private static readonly InstanceDependencyProperty MainPromptProperty = InstanceDependencyProperty.Register("MainPrompt", typeof(PromptBuilder), typeof(SpeechStatementActivity), InstanceDependencyPropertyOption.Default);
    [NonSerialized]
    private static readonly DependencyProperty TurnStartingEvent = DependencyProperty.Register("TurnStarting", typeof(EventHandler<SpeechTurnStartingEventArgs>), typeof(SpeechStatementActivity));

    // Events
    [CommunicationsWorkflowDescription("TurnStartingDesc")]
    public event EventHandler<SpeechTurnStartingEventArgs> TurnStarting
    {
        add
        {
            base.AddHandler(TurnStartingEvent, value);
        }
        remove
        {
            base.RemoveHandler(TurnStartingEvent, value);
        }
    }

    // Methods
    public SpeechStatementActivity()
    {
        this._instanceDependencyProperties = new Dictionary<string, object>();
    }

    public SpeechStatementActivity(string name) : base(name)
    {
        this._instanceDependencyProperties = new Dictionary<string, object>();
    }

    protected override ActivityExecutionStatus Cancel(ActivityExecutionContext executionContext)
    {
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x17, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        return this.Cleanup(ActivityExecutionStatus.Canceling);
    }

    private ActivityExecutionStatus Cleanup(ActivityExecutionStatus status)
    {
        if (this._isAsyncRunning)
        {
            if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
            {
                WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x19, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
            }
            this._callProvider.Synthesizer.SpeakAsyncCancelAll();
            return status;
        }
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x1a, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        this.RemoveHandlers();
        return ActivityExecutionStatus.Closed;
    }

    protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
    {
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x16, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        this._queueName = executionContext.CreateWorkflowQueueAndListen();
        this._communicationsWorkflowRuntimeService = executionContext.GetServiceOrThrow<CommunicationsWorkflowRuntimeService>();
        if (this.IsDataTrackingEnabled)
        {
            this._trackingDataWorkflowRuntimeService = executionContext.GetServiceOrThrow<TrackingDataWorkflowRuntimeService>();
        }
        this._speechDebuggingWorkflowRuntimeService = executionContext.GetService<UcmaSpeechDebuggingWorkflowRuntimeService>();
        this._callProvider = this.GetCallProviderFromParent<AudioVideoCall>();
        ActivityHelper.CheckCallEstablished(this, this._callProvider.Call);
        Call call = this._callProvider.Call;
        if (!this.HasCallDisconnectedEventActivity())
        {
            this._callStatusChangedProxy = new EventHandlerProxy<CallStateChangedEventArgs>(this._communicationsWorkflowRuntimeService, base.WorkflowInstanceId, this._queueName, new EventHandler<CallStateChangedEventArgs>(this.HandleAudioVideoCallStateChanged));
            call.StateChanged += new EventHandler<CallStateChangedEventArgs>(this._callStatusChangedProxy.EventHandler);
        }
        this._configurationChangedProxy = new EventHandlerProxy<AudioVideoFlowConfigurationChangedEventArgs>(this._communicationsWorkflowRuntimeService, base.WorkflowInstanceId, this._queueName, new EventHandler<AudioVideoFlowConfigurationChangedEventArgs>(this.HandleAudioVideoConfigurationChanged));
        HoldRetrieveHelper.GetAudioVideoFlow(call).ConfigurationChanged += new EventHandler<AudioVideoFlowConfigurationChangedEventArgs>(this._configurationChangedProxy.EventHandler);
        if (HoldRetrieveHelper.GetCallConfiguration(call) == CommunicationsEvent.CallOnHold)
        {
            this._callOnHold = true;
            return ActivityExecutionStatus.Executing;
        }
        this._callOnHold = false;
        if (this._callProvider.Call.State == CallState.Established)
        {
            this.StartSpeakAsync();
        }
        return ActivityExecutionStatus.Executing;
    }

    private void HandleAudioVideoCallStateChanged(object sender, CallStateChangedEventArgs e)
    {
        ActivityHelper.HandleCallStateChanged(this, e, base.WorkflowInstanceId);
    }

    private void HandleAudioVideoConfigurationChanged(object sender, AudioVideoFlowConfigurationChangedEventArgs e)
    {
        if ((HoldRetrieveHelper.GetCallConfiguration(this._callProvider.Call) == CommunicationsEvent.CallRetrieved) && this._callOnHold)
        {
            this._callOnHold = false;
            if (this._callProvider.Call.State == CallState.Established)
            {
                this.StartSpeakAsync();
            }
        }
        else if ((HoldRetrieveHelper.GetCallConfiguration(this._callProvider.Call) == CommunicationsEvent.CallOnHold) && !this._callOnHold)
        {
            this._callOnHold = true;
            if (this._callProvider.Call.State == CallState.Established)
            {
                if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
                {
                    WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 12, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
                }
                this._callProvider.Synthesizer.SpeakAsyncCancelAll();
            }
        }
    }

    protected override ActivityExecutionStatus HandleFault(ActivityExecutionContext context, Exception exception)
    {
        if ((Wpp.tracer.Level >= 2) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pGs(0x1f, 0x18, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId, TraceProvider.MakeStringArg(exception.ToString()));
        }
        base.HandleFault(context, exception);
        return this.Cleanup(ActivityExecutionStatus.Faulting);
    }

    internal void HandleSynthesizerSpeakCompleted(object sender, SpeakCompletedEventArgs e)
    {
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pGs(0x1f, 13, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId, TraceProvider.MakeStringArg(((e.Error != null) && (e.Error.Message != null)) ? e.Error.Message : "null"));
        }
        this._callProvider.Synthesizer.SpeakCompleted -= new EventHandler<SpeakCompletedEventArgs>(this._speakCompletedProxy.EventHandler);
        this._speakCompletedProxy = null;
        this._isAsyncRunning = false;
        this._callProvider.StopSynthesisConnector();
        if (((e.Error != null) && !(e.Error is OperationCanceledException)) && !(e.Error is EndOfStreamException))
        {
            throw e.Error;
        }
        if (!this._callOnHold || !e.Cancelled)
        {
            if (!e.Cancelled && this.IsDataTrackingEnabled)
            {
                if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
                {
                    WPP_8ab9099442760c3c15025a307460a9d4.WPP_pGss(0x1f, 14, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId, TraceProvider.MakeStringArg("MainPrompt"), TraceProvider.MakeStringArg(this.MainPrompt.ToXml()));
                }
                ActivityTrackingData item = new ActivityTrackingData(base.Name, base.WorkflowInstanceId);
                item.AddTrackingDataProperty(new TrackingDataProperty("MainPrompt", new ActivityXmlData(this.MainPrompt.ToXml())));
                this._trackingDataWorkflowRuntimeService.AddTrackingData(base.WorkflowInstanceId, item);
            }
            this.RemoveHandlers();
            base.Invoke<EventArgs>(new EventHandler<EventArgs>(ActivityHelper.CloseActivity), EventArgs.Empty);
        }
    }

    protected override void OnClosed(IServiceProvider provider)
    {
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 11, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        if (this._queueName != null)
        {
            provider.RemoveWorkflowQueue(this._queueName);
        }
    }

    private void OnTurnStarting()
    {
        if (TurnStartingEvent != null)
        {
            if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
            {
                WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 20, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
            }
            SpeechTurnStartingEventArgs e = new SpeechTurnStartingEventArgs(this.MainPrompt, PromptType.Main);
            base.RaiseGenericEvent<SpeechTurnStartingEventArgs>(TurnStartingEvent, this, e);
        }
        if (this.MainPrompt.IsTextEmpty())
        {
            if ((Wpp.tracer.Level >= 2) && ((Wpp.tracer.Flags & 1) != 0))
            {
                WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x15, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
            }
            throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture, ResourceExceptions.MainPromptEmpty, new object[] { base.Name }));
        }
    }

    private void RemoveHandlers()
    {
        if (this._callProvider != null)
        {
            if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
            {
                WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x1b, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
            }
            if (this._speakCompletedProxy != null)
            {
                this._callProvider.Synthesizer.SpeakCompleted -= new EventHandler<SpeakCompletedEventArgs>(this._speakCompletedProxy.EventHandler);
                this._speakCompletedProxy = null;
            }
            if (this._callStatusChangedProxy != null)
            {
                this._callProvider.Call.StateChanged -= new EventHandler<CallStateChangedEventArgs>(this._callStatusChangedProxy.EventHandler);
                this._callStatusChangedProxy = null;
            }
            if (this._configurationChangedProxy != null)
            {
                HoldRetrieveHelper.GetAudioVideoFlow(this._callProvider.Call).ConfigurationChanged -= new EventHandler<AudioVideoFlowConfigurationChangedEventArgs>(this._configurationChangedProxy.EventHandler);
                this._configurationChangedProxy = null;
            }
        }
    }

    private void StartSpeakAsync()
    {
        this._speakCompletedProxy = new EventHandlerProxy<SpeakCompletedEventArgs>(this._communicationsWorkflowRuntimeService, base.WorkflowInstanceId, this._queueName, new EventHandler<SpeakCompletedEventArgs>(this.HandleSynthesizerSpeakCompleted));
        this._callProvider.Synthesizer.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(this._speakCompletedProxy.EventHandler);
        this.OnTurnStarting();
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 15, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        PromptBuilder mainPrompt = this.MainPrompt;
        if (this._speechDebuggingWorkflowRuntimeService != null)
        {
            ISpeechDebugging speechDebugger = this._speechDebuggingWorkflowRuntimeService.GetSpeechDebugger(base.WorkflowInstanceId);
            if (speechDebugger != null)
            {
                if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
                {
                    WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x10, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
                }
                speechDebugger.OnSpeakAsync(this._callProvider.Synthesizer, mainPrompt.ToXml());
            }
        }
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pGs(0x1f, 0x11, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId, TraceProvider.MakeStringArg(this.MainPrompt.Culture));
        }
        CultureInfo workflowCulture = this._communicationsWorkflowRuntimeService.GetWorkflowCulture(base.WorkflowInstanceId);
        if (workflowCulture != null)
        {
            this.MainPrompt.Culture = workflowCulture;
            if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
            {
                WPP_8ab9099442760c3c15025a307460a9d4.WPP_pGs(0x1f, 0x12, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId, TraceProvider.MakeStringArg(this.MainPrompt.Culture));
            }
        }
        try
        {
            this._callProvider.StartSynthesisConnector();
        }
        catch (InvalidOperationException)
        {
            return;
        }
        if ((Wpp.tracer.Level >= 5) && ((Wpp.tracer.Flags & 1) != 0))
        {
            WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 0x13, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
        }
        this._isAsyncRunning = true;
        this._callProvider.Synthesizer.SpeakAsync(mainPrompt);
    }

    // Properties
    [CommunicationsWorkflowDescription("IsDataTrackingEnabledDesc")]
    public bool IsDataTrackingEnabled
    {
        get
        {
            return (base.DesignMode ? ((bool) InstanceDependencyHelper.GetValue<SpeechStatementActivity>(this, IsDataTrackingEnabledProperty)) : ((bool) InstanceDependencyHelper.GetValue<SpeechStatementActivity>(this, base.WorkflowInstanceId, IsDataTrackingEnabledProperty)));
        }
        set
        {
            if (base.DesignMode)
            {
                InstanceDependencyHelper.SetValue<SpeechStatementActivity>(this, IsDataTrackingEnabledProperty, value);
            }
            else
            {
                InstanceDependencyHelper.SetValue<SpeechStatementActivity>(this, base.WorkflowInstanceId, IsDataTrackingEnabledProperty, value);
            }
        }
    }

    [CommunicationsWorkflowDescription("MainPromptDesc"), TypeConverter(typeof(PromptBuilderTypeConverter)), CommunicationsWorkflowSerializer(typeof(PromptBuilderCodeDomSerializer))]
    public PromptBuilder MainPrompt
    {
        get
        {
            PromptBuilder builder = base.DesignMode ? ((PromptBuilder) InstanceDependencyHelper.GetValue<SpeechStatementActivity>(this, MainPromptProperty)) : ((PromptBuilder) InstanceDependencyHelper.GetValue<SpeechStatementActivity>(this, base.WorkflowInstanceId, MainPromptProperty));
            if (builder == null)
            {
                builder = new PromptBuilder(CultureInfo.CurrentUICulture);
                if (base.DesignMode)
                {
                    InstanceDependencyHelper.SetValue<SpeechStatementActivity>(this, MainPromptProperty, builder);
                    return builder;
                }
                InstanceDependencyHelper.SetValue<SpeechStatementActivity>(this, base.WorkflowInstanceId, MainPromptProperty, builder);
            }
            return builder;
        }
        set
        {
            if (base.DesignMode)
            {
                InstanceDependencyHelper.SetValue<SpeechStatementActivity>(this, MainPromptProperty, value);
            }
            else
            {
                if ((Wpp.tracer.Level >= 2) && ((Wpp.tracer.Flags & 1) != 0))
                {
                    WPP_8ab9099442760c3c15025a307460a9d4.WPP_pG(0x1f, 10, (IntPtr) this.GetHashCode(), base.WorkflowInstanceId);
                }
                throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture, ResourceExceptions.PropertyDesignTimeOnly, new object[] { "MainPrompt" }));
            }
        }
    }

    Dictionary<string, object> IInstanceDependencyContainer.InstanceDependencyProperties
    {
        get
        {
            return this._instanceDependencyProperties;
        }
    }

    // Nested Types
    internal sealed class StatementActivityValidator : ActivityValidator
    {
        // Methods
        public override ValidationErrorCollection Validate(ValidationManager manager, object obj)
        {
            ValidationErrorCollection errors = base.Validate(manager, obj);
            SpeechStatementActivity activity = obj as SpeechStatementActivity;
            if ((!ValidatorUtils.IsEventAttached(activity, SpeechStatementActivity.TurnStartingEvent) && !ValidatorUtils.IsExecutingEventAttached(activity)) && ((activity.MainPrompt == null) || activity.MainPrompt.IsTextEmpty()))
            {
                errors.Add(new ValidationError(Resource.ActivityValidator_MainPromptMissing, 0x10e0, true, "MainPrompt"));
            }
            return errors;
        }
    }
}


}
