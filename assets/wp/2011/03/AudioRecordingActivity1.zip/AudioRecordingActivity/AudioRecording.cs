﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections.Generic;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.Rtc.Workflow.Activities;
using Microsoft.Rtc.Workflow.Common;
using Microsoft.Rtc.Collaboration.AudioVideo;
using Microsoft.Rtc.Collaboration;
using System.Threading;

namespace AudioRecordingActivity
{
    public partial class AudioRecording : System.Workflow.ComponentModel.Activity
    {
        private CallProvider _callProvider;
        private DateTime _audioDetected;
        private Recorder _recorder;
        private Timer _silenceTimer;

        // Event to return the length of our recording
        public delegate void RecordingCompleteEventHandler(TimeSpan recordingLength);
        public event RecordingCompleteEventHandler RecordingComplete;
        protected void OnRecordingComplete(TimeSpan recordingLength) { RecordingComplete(recordingLength); }


        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            this._callProvider = Utilities.GetCallProviderFromParent<AudioVideoCall>(this);
            Call call = this._callProvider.Call;

            try
            {
                if (this._callProvider.Call.State == CallState.Established)
                {
                    _recorder = new Recorder();
                    _recorder.VoiceActivityChanged += new EventHandler<VoiceActivityChangedEventArgs>(_recorder_VoiceActivityChanged);
                    

                    WmaFileSink fileSink;
                    if(string.IsNullOrEmpty(FileName))
                        fileSink = new WmaFileSink(Guid.NewGuid() + ".wma");
                    else
                        fileSink = new WmaFileSink(FileName);

                    fileSink.EncodingFormat = EncodingFormat;
   
                    _recorder.SetSink(fileSink);

                    AudioVideoCall avCall = (AudioVideoCall)_callProvider.Call;
                    _recorder.AttachFlow(avCall.Flow);

                    _recorder.Start();
                    while (_recorder.State == RecorderState.Started)
                    {
                        // Loop while we wait for things to be done
                    }
                    OnRecordingComplete(DateTime.Now - _audioDetected);

                }
                return ActivityExecutionStatus.Closed;
            }
            catch
            {
                return ActivityExecutionStatus.Faulting;
            }
        }

        protected override ActivityExecutionStatus Cancel(ActivityExecutionContext executionContext)
        {
            this.Stop();
            return ActivityExecutionStatus.Canceling;
        }

        private void _recorder_VoiceActivityChanged(object sender, VoiceActivityChangedEventArgs e)
        {
            bool audioDetected = e.IsVoice;

            if (audioDetected) // Audio activity was detected
            {
                Console.WriteLine("Audio Activity Detected");
                _audioDetected = DateTime.Now; // Note the time we started getting audio        
                if (_silenceTimer != null)
                {
                    // We've got audio so make sure we don't have a silence timer going
                    _silenceTimer.Dispose();
                    _silenceTimer = null;
                }
            }
            else // We have silence
            {
                if (_audioDetected.Ticks == 0)
                {
                    // This means we've never had audio. Time to start checking to initial silence
                    Console.WriteLine("Starting Initial Silence Detection");
                    _silenceTimer = new Timer(new TimerCallback(OnSilenceTimerFired), null, InitialSilenceTimeout, new TimeSpan(0, 0, 0, 0, -1));
                }
                else
                {
                    // We've had audio so now we're looking for ending silence
                    Console.WriteLine("Starting Ending Silence Detection");
                    _silenceTimer = new Timer(new TimerCallback(OnSilenceTimerFired), null, EndingSilenceTimeout, new TimeSpan(0, 0, 0, 0, -1));
                }
            }
        }

        private void OnSilenceTimerFired(object state)
        {
            if (this._recorder.State != RecorderState.Stopped)
            {
                Console.WriteLine("Silence Timeout Detected");
                this.Stop();
            }
        }

        public void Stop()
        {
            if (_silenceTimer != null)
            {
                // Make sure we don't have a silence timer going
                _silenceTimer.Dispose();
                _silenceTimer = null;
            }

            // Set out recording length
            //_recordingLength = DateTime.Now - _recordingBegan;

            _recorder.Stop();
        }

        #region Initial Silence Timeout
        public static DependencyProperty InitialSilenceTimeoutProperty = System.Workflow.ComponentModel.DependencyProperty.Register(
                                                                        "InitialSilenceTimeout",
                                                                        typeof(TimeSpan),
                                                                        typeof(AudioRecording),
                                                                        new PropertyMetadata(new TimeSpan(0, 0, 0, 1, 500)));
        [Description("How long should we record silence before we decide the calling isn’t going to start talking")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public TimeSpan InitialSilenceTimeout
        {
            get { return ((TimeSpan)(base.GetValue(AudioRecording.InitialSilenceTimeoutProperty))); }
            set { base.SetValue(AudioRecording.InitialSilenceTimeoutProperty, value); }
        }
        #endregion

        #region Ending Silence Timeout
        public static DependencyProperty EndingSilenceTimeoutProperty = System.Workflow.ComponentModel.DependencyProperty.Register(
                                                                "EndingSilenceTimeout",
                                                                typeof(TimeSpan),
                                                                typeof(AudioRecording),
                                                                new PropertyMetadata(new TimeSpan(0, 0, 0, 0, 850)));
        [Description("How long should we record silence before we decided the caller has stopped talking")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public TimeSpan EndingSilenceTimeout
        {
            get { return ((TimeSpan)(base.GetValue(AudioRecording.EndingSilenceTimeoutProperty))); }
            set { base.SetValue(AudioRecording.EndingSilenceTimeoutProperty, value); }
        }
        #endregion

        #region File Name
        public static DependencyProperty FileNameProperty = System.Workflow.ComponentModel.DependencyProperty.Register(
                                                                "FileName",
                                                                typeof(string),
                                                                typeof(AudioRecording));
        [Description("Full path where we should save the file")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public string FileName
        {
            get { return ((string)(base.GetValue(AudioRecording.FileNameProperty))); }
            set { base.SetValue(AudioRecording.FileNameProperty, value); }
        }
        #endregion

        #region Encoding Format
        public static DependencyProperty EncodingFormatProperty = System.Workflow.ComponentModel.DependencyProperty.Register(
                                                                "EncodingFormat",
                                                                typeof(WmaEncodingFormat),
                                                                typeof(AudioRecording),
                                                                 new PropertyMetadata(WmaEncodingFormat.Pcm16Khz));
        [Description("Encoding Format to use for the file")]
        [Category("Behavior")]
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public WmaEncodingFormat EncodingFormat
        {
            get { return ((WmaEncodingFormat)(base.GetValue(AudioRecording.EncodingFormatProperty))); }
            set { base.SetValue(AudioRecording.EncodingFormatProperty, value); }
        }
        #endregion
    }
}
