﻿using System;
using System.Diagnostics;
using System.Workflow.Activities;
using Microsoft.Speech.Recognition;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;

namespace AudioRecordingSample
{
    public partial class Workflow1 : SequentialWorkflowActivity
    {
        private void HandleGeneralFault(object sender, EventArgs e)
        {
            string errorMessage = generalFaultHandler.Fault.ToString();
            Trace.Write(errorMessage);
            if (Debugger.IsAttached)
            {
                Debugger.Break();
            }
        }

        private void HandleCallDisconnectedEvent(object sender, EventArgs e)
        {
        }

        /* After we've recorded our audio, this event returns the length of the recorded audio.
         * This could easily be expanded to return other details if needed */
        private void audioRecording1_RecordingComplete(TimeSpan recordingLength)
        {
            speechStatementActivity1.MainPrompt.SetText("We recorded " + Math.Round(recordingLength.TotalSeconds, 1).ToString() + " seconds of audio");
        }
    }
}
