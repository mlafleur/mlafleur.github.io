﻿using System;
using System.Diagnostics;
using System.Workflow.Activities;
using Microsoft.Speech.Recognition;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;

namespace AudioRecordingSample
{
    public partial class Workflow1 : SequentialWorkflowActivity
    {
        private void HandleGeneralFault(object sender, EventArgs e)
        {
            string errorMessage = generalFaultHandler.Fault.ToString();
            Trace.Write(errorMessage);
            if (Debugger.IsAttached)
            {
                Debugger.Break();
            }
        }

        private void HandleCallDisconnectedEvent(object sender, EventArgs e)
        {
        }

        private void speechStatementActivity1_TurnStarting(object sender, Microsoft.Rtc.Workflow.Activities.SpeechTurnStartingEventArgs e)
        {

        }

        private void setPrompt_ExecuteCode(object sender, EventArgs e)
        {
            speechStatementActivity1.MainPrompt.ClearContent();
            speechStatementActivity1.MainPrompt.AppendText("We recorded ");
            speechStatementActivity1.MainPrompt.AppendText(audioRecording1.RecordingLength.TotalSeconds.ToString());
            speechStatementActivity1.MainPrompt.AppendText(" seconds of audio");
        }
    }
}
