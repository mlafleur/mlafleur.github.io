﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Rtc.Workflow.Common;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.Rtc.Workflow.Activities;
using Microsoft.Rtc.Collaboration;
using Microsoft.Rtc.Workflow;

namespace AudioRecordingActivity
{
    public static class Utilities
    {
        public static CallProvider GetCallProviderFromParent<T>(this Activity activity) where T : Call
        {
            CompositeActivity parent = activity.Parent;
            if (parent != null)
            {
                CommunicationsSequenceActivity parentActivity = parent as CommunicationsSequenceActivity;
                if ((parentActivity == null) || (parentActivity.GetBinding(CommunicationsSequenceActivity.CallProviderProperty) == null))
                {
                    // Walk up the tree if needed
                    return parent.GetCallProviderFromParent<T>();
                }
                if (parentActivity.CallProvider == null) throw new InvalidOperationException("No Call Provider");
                if (parentActivity.CallProvider.Call == null) throw new InvalidOperationException("No Call");
                if (parentActivity.CallProvider.Call is T) return parentActivity.CallProvider;
                throw new InvalidOperationException("Invalid Call Type");
            }
            throw new InvalidOperationException("No Call Provider Bound");
        }

        public static void Logging(string statment)
        {
            Console.WriteLine("Audio Record Activity: " + statment);
            System.Diagnostics.Debug.WriteLine("Audio Record Activity: " + statment);
        }
    }
}
