﻿using SettingsPaneExample.Common;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace SettingsPaneExample
{
    sealed partial class App : Application
    {

        bool settingsPaneEventRegistered = false;

        public App()
        {
            this.InitializeComponent();
            this.Suspending += OnSuspending;
        }

        protected override async void OnLaunched(LaunchActivatedEventArgs args)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            if (rootFrame == null)
            {
                rootFrame = new Frame();
                SuspensionManager.RegisterFrame(rootFrame, "AppFrame");
                if (args.PreviousExecutionState == ApplicationExecutionState.Terminated)
                {
                    try { await SuspensionManager.RestoreAsync(); }
                    catch (SuspensionManagerException) { }
                }
                Window.Current.Content = rootFrame;
            }
            if (rootFrame.Content == null)
                if (!rootFrame.Navigate(typeof(GroupedItemsPage), "AllGroups"))
                    throw new Exception("Failed to create initial page");

            Window.Current.Activate();

            // Register the Settings Pane Commands
            if (!this.settingsPaneEventRegistered)
            {
                Windows.UI.ApplicationSettings.SettingsPane.GetForCurrentView().CommandsRequested += SettingsPane_CommandsRequested;
                settingsPaneEventRegistered = true;
            }
        }

        // Create our commands when the Settings Pane requests them
        public void SettingsPane_CommandsRequested(Windows.UI.ApplicationSettings.SettingsPane sender, Windows.UI.ApplicationSettings.SettingsPaneCommandsRequestedEventArgs args)
        {
            Windows.UI.Popups.UICommandInvokedHandler handler = new Windows.UI.Popups.UICommandInvokedHandler(SettingsPane_CommandSelected);
            args.Request.ApplicationCommands.Add(new Windows.UI.ApplicationSettings.SettingsCommand("urlExample", "Go to a URL", handler));
            args.Request.ApplicationCommands.Add(new Windows.UI.ApplicationSettings.SettingsCommand("dialogExample", "Open a Dialog", handler));
        }

        // Executed when the user selects one of the commands from our Settings Page
        public async void SettingsPane_CommandSelected(Windows.UI.Popups.IUICommand command)
        {
            Windows.UI.ApplicationSettings.SettingsCommand settingsCommand = (Windows.UI.ApplicationSettings.SettingsCommand)command;
            if (settingsCommand.Id.ToString() == "urlExample")
            {
                // Open a web browser pointed to the best site on the web. :)
                Uri location = new Uri("http://massivescale.com/");
                await Windows.System.Launcher.LaunchUriAsync(location);
            }
            else if (settingsCommand.Id.ToString() == "dialogExample")
            {
                await new Windows.UI.Popups.MessageDialog("This is a sample dialog box", "Dialog Sample").ShowAsync();
            }
        }

        private async void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            await SuspensionManager.SaveAsync();
            deferral.Complete();
        }
    }
}
